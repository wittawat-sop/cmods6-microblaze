/*
 * main.c
 *
 *  Created on: Aug 2, 2022
 *      Author: wittawat
 */
#include "xparameters.h"
#include "xgpio_l.h"

int main()
{
	unsigned long i;
	while(1){
		XGpio_WriteReg(XPAR_LEDS_BASEADDR,0,0xAA);
		for(i=0;i<1000000;i++);
		XGpio_WriteReg(XPAR_LEDS_BASEADDR,0,0x55);
		for(i=0;i<1000000;i++);
	}
	return 0;
}

